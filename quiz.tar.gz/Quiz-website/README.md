# Quiz-website
A small website using Html,Css,javascript. 
QUIZ-WEBSITE

I used HTML,CSS AND JavaScript to make a website for simple quizzing which contains MCQs and has a timer as well and displays final percentage of marks obtained after the end of quiz.


->Technologies Used:

  1.HTML

  2.CSS

  3.Javascript
 

->Specialities of the website

  a.The quiz has various MCQ questions.
 
  b.There is a timer of 10 seconds within which one has to answer each problem.
 
  c.Final percentage of marks is displayed at the end of test.
 
  d.Emojies are also display according to score.
 
  e.The user gets to know answer instantly whether the current question s/he attempted was wrong or right.
